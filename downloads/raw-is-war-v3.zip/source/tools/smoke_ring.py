"""Boot a real SNES core, navigate to a match, and capture gameplay evidence."""
import argparse
import ctypes as C
from pathlib import Path

import numpy as np
from PIL import Image

from headless_snes import Emulator

parser = argparse.ArgumentParser()
parser.add_argument('--rom', type=Path, required=True)
parser.add_argument('--core', type=Path, required=True)
parser.add_argument('--output-dir', type=Path, required=True)
parser.add_argument('--expect-raw', action='store_true')
parser.add_argument('--ring', choices=('HWA', 'HWF', 'RANDOM'), default='HWA')
parser.add_argument('--sram', type=Path, help='Load an existing SRAM file before boot')
parser.add_argument('--save-sram', type=Path, help='Write SRAM after gameplay')
args = parser.parse_args()
args.output_dir.mkdir(parents=True, exist_ok=True)
e = Emulator(args.rom, args.core)
# No save state is loaded. An optional existing SRAM file exercises persistence.
if args.sram:
    saved = args.sram.read_bytes()
    size = e.core.retro_get_memory_size(0)
    assert len(saved) == size, (len(saved), size)
    C.memmove(e.core.retro_get_memory_data(0), saved, size)
e.run(1200)
e.press('start'); e.run(150)
# Use Dream Match: Championship mode locks the ring choice to its preset.
e.press('down')
e.press('b'); e.run(150)
if args.ring != 'HWA':
    for _ in range(4):
        e.press('down')
    for _ in range(('HWA', 'HWF', 'RANDOM').index(args.ring)):
        e.press('right')
e.image(args.output_dir / 'options.png')
e.press('start'); e.run(450)
e.press('b'); e.run(45)
e.press('b'); e.run(150)
e.press('b'); e.run(45)
e.press('right')
e.press('b'); e.run(45)
e.press('b'); e.run(600)
e.press('b'); e.run(900)
e.image(args.output_dir / 'match.png')
e.run(300, ['down'])
e.image(args.output_dir / 'apron.png')
e.run(120, ['up'])
e.image(args.output_dir / 'movement.png')
e.run(600)
e.image(args.output_dir / 'later.png')
if args.save_sram:
    size = e.core.retro_get_memory_size(0)
    args.save_sram.write_bytes(C.string_at(e.core.retro_get_memory_data(0), size))
before = np.asarray(Image.open(args.output_dir / 'match.png')).astype(int)
apron = np.asarray(Image.open(args.output_dir / 'apron.png')).astype(int)
after = np.asarray(Image.open(args.output_dir / 'later.png')).astype(int)
assert before.shape == (224, 256, 3), before.shape
assert np.count_nonzero(np.max(abs(after - before), axis=2) > 16) > 500, 'No visible gameplay progression'
if args.expect_raw:
    # RGB565 and XRGB8888 differ by at most two levels when expanding green.
    grey_mat = np.max(abs(before - (205, 213, 222)), axis=2) <= 2
    assert np.count_nonzero(grey_mat) > 3000, 'Expected the RAW light grey ring mat'
    area = apron[40:190]
    lettering = np.max(abs(area - (213, 8, 16)), axis=2) <= 2
    assert np.count_nonzero(lettering) > 150, 'Expected red RAW apron lettering'
print('PASS: cold boot, match startup, movement, and 600 further gameplay frames')
print('Screenshots:', args.output_dir)

# Undertaker — Ministry 1998–1999 — v1

RAW IS WAR ring v3 + ayrı Undertaker edit karakteri.

## Kurulum — Snes9x 1.62.3

1. Snes9x'i kapatıp ZIP'i yeni bir klasöre çıkar.
2. `raw-ministry-undertaker-v1.srm` dosyasını Snes9x'in SRAM/Battery kayıt klasörüne koy. Bu klasör ROM klasörü olarak ayarlıysa SFC ve SRM'yi aynı yerde tutman yeterli. İki dosyanın adları uzantıları dışında aynı olmalı.
3. Snes9x'te `raw-ministry-undertaker-v1.sfc` dosyasını aç. Eski save state'i yükleme; oyunu normal açılıştan başlat.
4. DREAM MATCH → karakter seçiminde L/R ile **EDIT** grubuna geç → **TAKER** seç.

**İki dosya da gerekli:** SFC ringi ve edit sınırını, SRM Undertaker kaydını içerir. EDIT grubu görünmüyorsa SRM emülatörün beklediği klasörde değildir. WC grubundaki TAKER eski yerleşik karakterdir.

Bu SRM yeni bir kayıt dosyasıdır; yalnız No001 Undertaker içerir. Önceki ilerleme/edit kayıtlarını bununla değiştirme. Yeni dosya adı eski RAW ring sürümünün kaydıyla çakışmaz. Hazır SFC'ye ayrıca IPS uygulama.

## Profil

- Siyah kıyafet/botlar, uzun saç ve mevcut Undertaker modeli/portresi.
- Tombstone Piledriver bitirici; ön grapple Y+B. Chokeslam, Big Boot (KENKA KICK), Flying Clothesline, DDT, side slam, suplex ve leg drop.
- Güç/dayanıklılık yüksek; submission ve eklem teknikleri daha düşük. Oyun nitelikleri 1–5 ölçeğindedir.
- FAST recovery, POWER counter, normal hız, daha yavaş köşeye çıkma, bitirici critical. 84 puan; edit sınırı 180.
- Boğaz kesme, diz çökerek kol kaldırma ve iki kolu kaldırma pozları.
- CPU son grapple aşamasında bitiriciyi daha sık tercih eder.
- Last Ride ve Hell's Gate yok.

Bu ilk sürüm mevcut SNES sprite'larını kullanır. Gönderilen görseldeki dövmeler ve Ministry göğüs sembolü birebir çizilmedi. Old School ip üstünde yürüme animasyonu ve özgün WWF giriş müziği eklenmedi.

## Paket

- Aynı adlı SFC + SRM: oynamak için.
- `*-from-raw-v3.ips`: yalnız kabul edilen RAW ring v3 ROM'una edit sınırı değişikliğini uygular. Karakter için yine SRM gerekir.
- Profil JSON'u, üretim/doğrulama notları ve gerçek emülasyon görüntüleri.

Resmî Snes9x 1.62.3 Linux libretro çekirdeğinde normal açılış, SAVE/LOAD, bitirici demoları ve CPU maçı test edildi. Undertaker 4:05'te pinle kazandı. 15.023 oyun karesi ve 35 dinamik ip girişi özgün grafiklerle karşılaştırıldı; bozulma görülmedi. Windows arayüzü bu ortamda çalıştırılmadı.
